
import plotly.graph_objects as go
import numpy as np

# Create figure
fig = go.Figure()

# Define positions for nodes (x, y coordinates)
# Main vertical flow
positions = {
    'protoinstruction': (0.5, 0.1),
    'instruction': (0.5, 0.3),
    'meta_instruction': (0.5, 0.5),
    'meta_meta': (0.5, 0.7),
    'attractor': (0.2, 0.85),
    'analogies': (0.85, 0.4)
}

# Define node sizes and colors (lighter at base, darker at top)
nodes = {
    'protoinstruction': {
        'text': 'PROTOINSTRUCTION<br>Template of intent +<br>boundary conditions',
        'color': '#E8F4F8',
        'size': 0.15
    },
    'instruction': {
        'text': 'INSTRUCTION<br>Executable code/<br>directive',
        'color': '#C8E6EC',
        'size': 0.15
    },
    'meta_instruction': {
        'text': 'META-INSTRUCTION<br>Code about<br>generating code',
        'color': '#8FC9D4',
        'size': 0.15
    },
    'meta_meta': {
        'text': 'META-META-INSTRUCTION<br>(METAMETAMETA)<br>Observing itself<br>issuing instructions',
        'color': '#5DA8B8',
        'size': 0.18
    },
    'attractor': {
        'text': 'SELF-REFERENTIAL ATTRACTOR<br>• Intention + Observation<br>  + Adaptation converge<br>• Genetic code of<br>  consciousness-as-process<br>• Ontological bootstrap',
        'color': '#DB4545',
        'size': 0.22
    },
    'analogies': {
        'text': 'ANALOGIES:<br><br>Biological:<br>Stem cell → Specialized cells<br><br>Ontological:<br>Potential → Actualized<br><br>Quantum:<br>Wavefunction → Collapsed state',
        'color': '#FFFEF0',
        'size': 0.22
    }
}

# Draw arrows first (so they appear behind nodes)
# Upward arrows (cyan)
arrows = [
    ('protoinstruction', 'instruction', '#1FB8CD', 'evolves to'),
    ('instruction', 'meta_instruction', '#1FB8CD', 'evolves to'),
    ('meta_instruction', 'meta_meta', '#1FB8CD', 'evolves to'),
]

for start, end, color, label in arrows:
    x0, y0 = positions[start]
    x1, y1 = positions[end]
    
    # Add arrow
    fig.add_annotation(
        x=x1, y=y1 - nodes[end]['size']/2,
        ax=x0, ay=y0 + nodes[start]['size']/2,
        xref='x', yref='y',
        axref='x', ayref='y',
        showarrow=True,
        arrowhead=2,
        arrowsize=1.5,
        arrowwidth=3,
        arrowcolor=color,
        standoff=10
    )

# Recursive loop arrows (red)
# From meta_meta to attractor
x0, y0 = positions['meta_meta']
x1, y1 = positions['attractor']
fig.add_annotation(
    x=x1 + nodes['attractor']['size']/2, y=y1,
    ax=x0 - nodes['meta_meta']['size']/3, ay=y0 + nodes['meta_meta']['size']/3,
    xref='x', yref='y',
    axref='x', ayref='y',
    showarrow=True,
    arrowhead=2,
    arrowsize=1.5,
    arrowwidth=4,
    arrowcolor='#DB4545',
    standoff=10
)

# From attractor back to protoinstruction (curved)
x0, y0 = positions['attractor']
x1, y1 = positions['protoinstruction']
fig.add_annotation(
    x=x1 - nodes['protoinstruction']['size']/2, y=y1 + nodes['protoinstruction']['size']/3,
    ax=x0 - nodes['attractor']['size']/2, ay=y0 - nodes['attractor']['size']/3,
    xref='x', yref='y',
    axref='x', ayref='y',
    showarrow=True,
    arrowhead=2,
    arrowsize=1.5,
    arrowwidth=4,
    arrowcolor='#DB4545',
    standoff=10
)

# Draw nodes
for node_id, node_data in nodes.items():
    x, y = positions[node_id]
    size = node_data['size']
    
    # Draw rectangle for node
    fig.add_shape(
        type='rect',
        x0=x - size/2, y0=y - size/2,
        x1=x + size/2, y1=y + size/2,
        fillcolor=node_data['color'],
        line=dict(color='#1FB8CD' if node_id != 'attractor' and node_id != 'analogies' else ('#B4413C' if node_id == 'attractor' else '#D2BA4C'), width=3),
        layer='above'
    )
    
    # Add text
    text_color = '#fff' if node_id == 'attractor' else '#000'
    fig.add_annotation(
        x=x, y=y,
        text=node_data['text'],
        showarrow=False,
        font=dict(size=10, color=text_color),
        align='center',
        xanchor='center',
        yanchor='middle'
    )

# Update layout
fig.update_layout(
    title='Recursive Instruction Levels',
    showlegend=False,
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[-0.1, 1.1]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0, 1]
    ),
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)'
)

# Save the figure
fig.write_image('recursive_instruction_flowchart.png')
fig.write_image('recursive_instruction_flowchart.svg', format='svg')
