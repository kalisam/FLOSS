
# Rose Seed Node (Docker, WSL2, Windows 10)

This spins up a **local Holochain seed node** with a Kitsune bootstrap server and WebRTC proxy.
It's a clean foundation to install your first Rose hApp when you have a `.hap` file.

## Prereqs
- Windows 10 + WSL2 + Docker Desktop (WSL2 backend)
- You already have Docker images; this compose references:
  - `ghcr.io/holochain/kitsune-bootstrap:latest`
  - `ghcr.io/holochain/webrtc-proxy:latest`
  - `ghcr.io/holochain/edge-node:latest`

## Quick start
```bash
# In WSL2
cd /mnt/data/rose_seed_node
docker compose up -d
docker compose logs -f holochain
```

When you see logs that the **admin interface is listening on 0.0.0.0:4444**
and **app interface on 0.0.0.0:8888**, your seed node is live.

## Installing your first app (.hap)
When you have a compiled `.hap` (your Rose Node DNA bundle):

1. Copy it into the `storage/` folder (mounted into the container).
2. Connect to the admin websocket on `ws://127.0.0.1:4444` using any Holochain admin client and issue:
   - `register_happ` with the path to your `.hap`
   - `install_app` with an `installed_app_id` (e.g., `"rose-node"`)
   - `enable_app`

> Tip: If you don't have a client yet, the `hc` CLI or minimal admin clients can perform these calls.

## Networking
- Local bootstrap: `http://localhost:5778`
- Local proxy: `ws://localhost:4443`

Peers can point their conductor configs to your public IP:PORT for bootstrap if you port-forward `5778` and `4443` from your router to this machine.

## Persisted Data
- `./lair` — Agent keys (lair keystore socket & data)
- `./storage` — Conductor databases and app storage
- `./config` — Conductor config

## Next Steps
- Build/obtain your Rose `.hap` bundle (identity, offers/needs, ledger, normkernel zomes).
- Publish a short **JOIN.md** with the DNA hash and a connection guide.
- (Optional) Add an `ad4m-host` service later to wrap zome calls with semantic APIs.
