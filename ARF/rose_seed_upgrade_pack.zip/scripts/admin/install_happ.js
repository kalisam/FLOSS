
// Minimal admin client to register/install/enable a .hap against Holochain admin WS.
// Usage: node install_happ.js --hap ./storage/rose-node.hap --id rose-node --admin ws://127.0.0.1:4444
//
// Requires: node >= 18
//
// Note: The admin API shape is intentionally minimal; adjust if your edge-node uses different RPC envelopes.

import fs from 'fs';
import WebSocket from 'ws';

function arg(name, def = undefined) {
  const i = process.argv.indexOf(name);
  if (i >= 0 && i + 1 < process.argv.length) return process.argv[i + 1];
  return def;
}

const HAP_PATH = arg('--hap');
const APP_ID = arg('--id', 'rose-node');
const ADMIN_WS = arg('--admin', 'ws://127.0.0.1:4444');

if (!HAP_PATH || !fs.existsSync(HAP_PATH)) {
  console.error('Missing or invalid --hap path');
  process.exit(1);
}

const hapBytes = fs.readFileSync(HAP_PATH);

const ws = new WebSocket(ADMIN_WS);

let msgId = 0;
function call(method, params) {
  return new Promise((resolve, reject) => {
    const id = (++msgId).toString();
    const payload = { id, type: 'request', request: { method, params } };
    ws.send(JSON.stringify(payload));
    const onMessage = (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.id === id) {
          ws.off('message', onMessage);
          if (msg.type === 'response' && !msg.error) resolve(msg.response);
          else reject(msg.error || msg);
        }
      } catch (e) {
        // ignore non-json frames
      }
    };
    ws.on('message', onMessage);
  });
}

ws.on('open', async () => {
  try {
    console.log('Connected to admin:', ADMIN_WS);

    // 1) register_happ
    console.log('Registering hApp...');
    await call('register_happ', { installed_app_id: APP_ID, happ_bundle: [...hapBytes] });

    // 2) install_app (if not already)
    console.log('Installing app...');
    await call('install_app', { installed_app_id: APP_ID });

    // 3) enable_app
    console.log('Enabling app...');
    await call('enable_app', { installed_app_id: APP_ID });

    console.log('✔ Done. App ID:', APP_ID);
    ws.close();
  } catch (e) {
    console.error('Error:', e);
    ws.close();
    process.exit(1);
  }
});

ws.on('error', (e) => {
  console.error('WebSocket error:', e);
});
