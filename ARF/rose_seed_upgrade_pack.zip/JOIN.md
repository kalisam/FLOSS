
# JOIN the Rose Forest (Seed)

Welcome! To join this mesh you need:
- Holochain conductor
- The Rose DNA bundle (`.hap`)
- This seed's bootstrap and proxy endpoints

## Endpoints (seed)
- Bootstrap: `http://<YOUR_PUBLIC_IP_OR_DOMAIN>:5778`
- Proxy: `ws://<YOUR_PUBLIC_IP_OR_DOMAIN>:4443`

## Steps
1. Get the `.hap` file from the releases page (or a trusted peer).
2. Run the conductor and point your config to the endpoints above.
3. Install the app:
   ```bash
   node scripts/admin/install_happ.js --hap ./storage/rose-node.hap --id rose-node --admin ws://127.0.0.1:4444
   ```
4. Share back your agent pubkey in the introductions channel.

## Governance (minimum)
- No god keys.
- All knowledge must pass **symbolic validation** in integrity zome.
- LLM outputs require validator consensus.
