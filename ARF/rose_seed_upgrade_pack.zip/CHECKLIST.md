
# Implementation Checklist (Symbolic‑First)

## Week 1 — Foundation
- [ ] Integrity zome with `KnowledgeTriple` + validation rules
- [ ] Bootstrap **Base Ontology** (`Entity`, `Concept`, `Agent`; `is_a`, `part_of`)
- [ ] Vector writes **require** a valid triple
- [ ] Try to add an invalid triple → expect rejection

## Week 2 — Domain Ontology
- [ ] AI/ML ontology (`AIModel`, `LLM`, `Dataset`; `trained_on`, `improves_upon`, `capable_of`)
- [ ] Inference axioms: transitivity + capability inheritance
- [ ] Validate with sample triples

## Week 3 — LLM as Assistant
- [ ] NL → Formal query parser (tool call)
- [ ] Triple extraction → **committee validation (3+ validators)**
- [ ] Formal results → NL formatter with full provenance

## Week 4 — Migration
- [ ] Convert existing embeddings → triples (with validator consensus)
- [ ] Link vectors to triples (index only)
- [ ] Deprecate direct vector storage routes
