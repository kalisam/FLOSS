
# Rose Seed: Upgrade Pack

This pack extends your existing seed with:
- `ad4m-host` (GraphQL @ :4000) for language/semantic APIs
- A minimal admin installer (`scripts/admin/install_happ.js`)
- Join + checklist docs
- JSON-schema stubs for ontologies

## Apply
1) Place these files into your existing seed folder (merge with the same structure).
2) If you already have a `docker-compose.yml`, compare & merge the `ad4m` service.
3) Start or restart:
```bash
docker compose up -d
docker compose logs -f ad4m
```
4) Install your `.hap`:
```bash
node scripts/admin/install_happ.js --hap ./storage/rose-node.hap --id rose-node --admin ws://127.0.0.1:4444
```
5) Expose ports if you want others to join:
   - 5778 (bootstrap), 4443 (proxy), optionally 4000 (ad4m GraphQL)
