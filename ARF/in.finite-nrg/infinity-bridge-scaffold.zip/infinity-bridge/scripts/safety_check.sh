#!/usr/bin/env bash
echo safety stub
