print('coherence demo stub')
