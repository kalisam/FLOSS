print('validator stub')
