print('stub orchestrator; run with --list-devices soon')
