print('archive-evidence stub; see full scaffold in docs')
