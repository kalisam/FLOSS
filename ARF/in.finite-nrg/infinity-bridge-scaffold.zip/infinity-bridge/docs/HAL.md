HAL docs
