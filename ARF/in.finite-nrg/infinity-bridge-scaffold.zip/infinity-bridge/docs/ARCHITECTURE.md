Scaffold docs
