# Week 1 Implementation Checklist - Symbolic-First Bootstrap

**Goal**: Deploy Holochain integrity zome with ontology validation by 2025-11-09

**Context**: ADR-0 validated (4.83/5), ADR-1 committed, production code ready

---

## Overview

```
Day 1-2: Deploy Integrity Zome
Day 3:   Bootstrap Ontology
Day 4-5: Wrap Storage Layer
Day 6:   Test Validation
Day 7:   Integration + Documentation
```

---

## Day 1-2: Deploy Holochain Integrity Zome

### Task 1.1: Set Up Holochain Development Environment
**Time**: 2 hours

**Actions**:
```bash
# Install Holochain
cargo install holochain --version 0.2.0

# Create new DNA
hc sandbox create flossi0ullk-dna

# Verify installation
hc --version
```

**Success criteria**: Can run `hc` commands

**Blockers**: None (standard Holochain install)

---

### Task 1.2: Copy Integrity Zome Code
**Time**: 3 hours

**Actions**:
1. Create `dnas/flossi0ullk/zomes/integrity/` directory
2. Copy code from `SYMBOLIC_FIRST_CORE.md` Part 1 (Integrity Zome)
3. Add to `Cargo.toml`

**Code structure**:
```
dnas/flossi0ullk/
├── zomes/
│   ├── integrity/
│   │   ├── src/
│   │   │   ├── lib.rs           # Main integrity zome
│   │   │   ├── triple.rs        # KnowledgeTriple definition
│   │   │   ├── ontology.rs      # Ontology types
│   │   │   └── validation.rs    # Validation rules
│   │   └── Cargo.toml
│   └── coordinator/
│       └── (Day 4-5)
└── dna.yaml
```

**Success criteria**: `cargo build` succeeds

**Blockers**: May need to adjust Holochain version compatibility

---

### Task 1.3: Define Core Structures
**Time**: 2 hours

**Key structures** (from SYMBOLIC_FIRST_CORE.md):

```rust
// triple.rs
#[hdk_entry_helper]
pub struct KnowledgeTriple {
    pub subject: String,
    pub predicate: String,
    pub object: String,
    pub confidence: f32,
    pub provenance: Provenance,
    pub timestamp: Timestamp,
}

// ontology.rs
#[hdk_entry_helper]
pub struct OntologyType {
    pub name: String,
    pub parent: Option<String>,
    pub constraints: Vec<Constraint>,
}

#[hdk_entry_helper]
pub struct OntologyRelation {
    pub name: String,
    pub domain: String,  // Valid subject types
    pub range: String,   // Valid object types
}
```

**Success criteria**: Structures compile, can create test instances

---

### Task 1.4: Implement Validation Logic
**Time**: 4 hours

**Core validation** (from SYMBOLIC_FIRST_CORE.md):

```rust
// validation.rs
pub fn validate_triple(
    triple: &KnowledgeTriple,
    ontology: &Ontology
) -> ExternResult<ValidateCallbackResult> {
    // 1. Type checking
    if !ontology.has_type(&triple.subject) {
        return Ok(ValidateCallbackResult::Invalid(
            format!("Unknown subject type: {}", triple.subject)
        ));
    }
    
    // 2. Relation checking
    let relation = ontology.get_relation(&triple.predicate)?;
    if !relation.allows_domain(&triple.subject) {
        return Ok(ValidateCallbackResult::Invalid(
            format!("Subject {} incompatible with predicate {}", 
                    triple.subject, triple.predicate)
        ));
    }
    
    // 3. Confidence bounds
    if triple.confidence < 0.0 || triple.confidence > 1.0 {
        return Ok(ValidateCallbackResult::Invalid(
            "Confidence must be in [0, 1]".to_string()
        ));
    }
    
    Ok(ValidateCallbackResult::Valid)
}
```

**Success criteria**: Unit tests pass for valid/invalid triples

---

### Task 1.5: Compile and Test Zome
**Time**: 3 hours

**Actions**:
```bash
# Build DNA
hc dna pack dnas/flossi0ullk

# Run sandbox
hc sandbox run

# Test basic validation
# (Will use conductor API in Day 6)
```

**Success criteria**: DNA packs without errors, sandbox starts

**Expected issues**: 
- Version mismatches → adjust dependencies
- Missing types → add stub implementations

---

## Day 3: Bootstrap Base Ontology

### Task 3.1: Define Base Types
**Time**: 2 hours

**From ONTOLOGIES_AND_INTEGRATION.md**:

```rust
// Bootstrap these types into the ontology
const BASE_TYPES: &[&str] = &[
    "Entity",       // Top-level
    "Agent",        // Can act
    "Resource",     // Can be used
    "Concept",      // Abstract idea
    "Event",        // Temporal occurrence
];
```

**Actions**:
1. Create `ontology_bootstrap.rs`
2. Add initialization function
3. Call on DNA genesis

**Success criteria**: Can query types via Holochain call

---

### Task 3.2: Define Base Relations
**Time**: 2 hours

**From ONTOLOGIES_AND_INTEGRATION.md**:

```rust
const BASE_RELATIONS: &[(&str, &str, &str)] = &[
    // (name, domain, range)
    ("is_a", "Entity", "Entity"),           // Subtyping
    ("part_of", "Entity", "Entity"),        // Composition
    ("capable_of", "Agent", "Event"),       // Capabilities
    ("requires", "Event", "Resource"),      // Dependencies
    ("improves", "Event", "Entity"),        // Enhancement
];
```

**Actions**:
1. Add to `ontology_bootstrap.rs`
2. Implement relation queries
3. Test type/relation lookup

**Success criteria**: Can query "what relations does 'Agent' support?"

---

### Task 3.3: Add AI/ML Domain Types
**Time**: 2 hours

**From ONTOLOGIES_AND_INTEGRATION.md**:

```rust
const AI_ML_TYPES: &[&str] = &[
    "LLM",              // Large language model
    "Embedding",        // Vector representation
    "KnowledgeGraph",   // Structured knowledge
    "Agent",            // AI agent
];

const AI_ML_RELATIONS: &[(&str, &str, &str)] = &[
    ("generates", "LLM", "Embedding"),
    ("queries", "Agent", "KnowledgeGraph"),
    ("improves", "Training", "LLM"),
];
```

**Actions**:
1. Extend base ontology with AI/ML types
2. Test domain-specific validation
3. Verify "GPT-4 generates text" validates

**Success criteria**: AI/ML triples validate correctly

---

## Day 4-5: Wrap Existing Storage

### Task 4.1: Create Validation Wrapper
**Time**: 4 hours

**Integration point** with `conversation_memory.py`:

```python
# conversation_memory_v2.py (with symbolic validation)

from holochain_client import HolochainClient

class ValidatedConversationMemory(ConversationMemory):
    def __init__(self, agent_id, holochain_client):
        super().__init__(agent_id)
        self.hc = holochain_client
    
    def transmit(self, understanding):
        # NEW: Extract and validate triples BEFORE storage
        triples = self._extract_triples(understanding)
        
        for triple in triples:
            # Call Holochain validation
            result = self.hc.call_zome(
                "flossi0ullk",
                "integrity",
                "validate_triple",
                triple
            )
            
            if not result['valid']:
                raise ValidationError(
                    f"Triple rejected: {result['reason']}"
                )
        
        # Only if all triples valid: proceed with storage
        return super().transmit(understanding)
    
    def _extract_triples(self, understanding):
        """
        Extract (subject, predicate, object) triples from text.
        For now: simple pattern matching.
        Later: LLM-assisted with consensus.
        """
        # TODO: Implement triple extraction
        # For Week 1: manual triples only
        return understanding.get('triples', [])
```

**Success criteria**: Validation call reaches Holochain

---

### Task 4.2: Add Holochain Client
**Time**: 2 hours

**Actions**:
```bash
pip install holochain-client-python

# Or use websocket directly:
pip install websockets
```

**Code**:
```python
# holochain_wrapper.py

import websockets
import json

class HolochainValidator:
    def __init__(self, conductor_url="ws://localhost:8888"):
        self.url = conductor_url
    
    async def validate_triple(self, subject, predicate, obj):
        async with websockets.connect(self.url) as ws:
            request = {
                "type": "call_zome",
                "data": {
                    "cell_id": [...],  # From sandbox
                    "zome_name": "integrity",
                    "fn_name": "validate_triple",
                    "payload": {
                        "subject": subject,
                        "predicate": predicate,
                        "object": obj,
                        "confidence": 1.0,
                        "provenance": {...}
                    }
                }
            }
            
            await ws.send(json.dumps(request))
            response = await ws.recv()
            return json.loads(response)
```

**Success criteria**: Can call Holochain from Python

---

### Task 4.3: Test Integration
**Time**: 4 hours

**Test cases**:

```python
# test_validation_integration.py

def test_valid_triple():
    memory = ValidatedConversationMemory(
        agent_id="test",
        holochain_client=HolochainValidator()
    )
    
    # Should SUCCEED
    memory.transmit({
        'content': "GPT-4 generates text",
        'triples': [
            ('GPT-4', 'generates', 'Text')
        ]
    })

def test_invalid_triple():
    memory = ValidatedConversationMemory(...)
    
    # Should FAIL
    with pytest.raises(ValidationError):
        memory.transmit({
            'content': "GPT-4 eats pizza",
            'triples': [
                ('GPT-4', 'eats', 'Pizza')
            ]
        })
```

**Success criteria**: Valid triples accepted, invalid rejected

---

## Day 6: Critical Validation Test

### Task 6.1: Run The Critical Test
**Time**: 2 hours

**The test from synthesis document**:

```python
# critical_test.py

def test_invalid_knowledge_rejected():
    """
    From synthesis: "attempt to add an invalid triple 
    (e.g., 'GPT-4 eats Pizza') and verify the integrity 
    zome rejects it"
    """
    
    validator = HolochainValidator()
    
    # This MUST fail
    result = validator.validate_triple(
        subject="GPT-4",
        predicate="eats",
        object="Pizza"
    )
    
    assert not result['valid']
    assert "GPT-4 is not organism" in result['reason']
    print("✅ CRITICAL TEST PASSED: Invalid triple rejected")

def test_valid_knowledge_accepted():
    """Verify valid triples are accepted"""
    
    validator = HolochainValidator()
    
    # This MUST succeed
    result = validator.validate_triple(
        subject="GPT-4",
        predicate="generates",
        object="Text"
    )
    
    assert result['valid']
    print("✅ Valid triple accepted")

if __name__ == "__main__":
    test_invalid_knowledge_rejected()
    test_valid_knowledge_accepted()
    print("\n🎉 ALL CRITICAL TESTS PASSED 🎉")
```

**Success criteria**: Both tests pass

---

### Task 6.2: Document Test Results
**Time**: 1 hour

**Actions**:
1. Run tests
2. Capture output
3. Create `WEEK_1_RESULTS.md`
4. Screenshot evidence

**Documentation**:
```markdown
# Week 1 Results - Symbolic-First Bootstrap

## Critical Test: Invalid Triple Rejection

**Test**: Attempt to add "GPT-4 eats Pizza"
**Expected**: Reject with clear reason
**Result**: ✅ PASS

```
[timestamp] Validation called
[timestamp] Subject type: LLM
[timestamp] Predicate: eats
[timestamp] Domain check: LLM not in domain of 'eats'
[timestamp] REJECT: "Subject 'GPT-4' (type: LLM) incompatible with predicate 'eats' (domain: Organism)"
```

## Test: Valid Triple Acceptance

**Test**: Add "GPT-4 generates Text"
**Expected**: Accept
**Result**: ✅ PASS
```

**Success criteria**: Documentation shows both tests working

---

## Day 7: Integration and Documentation

### Task 7.1: Update conversation_memory.py
**Time**: 2 hours

**Actions**:
1. Integrate validation layer
2. Add error handling
3. Update tests

**Success criteria**: All ADR-0 tests still pass + validation working

---

### Task 7.2: Create Integration Guide
**Time**: 2 hours

**Document**: `SYMBOLIC_FIRST_INTEGRATION_GUIDE.md`

**Contents**:
- How to use validated memory
- How to add new types to ontology
- How to add new relations
- How to handle validation errors
- Migration path for existing data

---

### Task 7.3: Update ADR-1 Status
**Time**: 1 hour

**Actions**:
1. Mark Week 1 tasks complete
2. Document any deviations
3. Note lessons learned
4. Set Week 2 goals

---

## Success Criteria (Week 1 Complete)

**Must have**:
- ✅ Holochain integrity zome deployed
- ✅ Base ontology bootstrapped (Entity, Agent, Resource, Concept)
- ✅ Validation working (invalid triples rejected)
- ✅ Integration with conversation_memory.py
- ✅ Critical test passing ("GPT-4 eats pizza" rejected)

**Nice to have**:
- ⏳ AI/ML ontology complete
- ⏳ Automatic triple extraction
- ⏳ Inference engine working

---

## Estimated Time Breakdown

| Day | Tasks | Hours | Cumulative |
|-----|-------|-------|------------|
| 1 | Holochain setup + integrity zome start | 8 | 8 |
| 2 | Complete integrity zome + compile | 8 | 16 |
| 3 | Bootstrap ontology | 6 | 22 |
| 4 | Validation wrapper start | 6 | 28 |
| 5 | Complete wrapper + integration | 6 | 34 |
| 6 | Critical test + documentation | 4 | 38 |
| 7 | Integration + final docs | 4 | 42 |

**Total**: ~42 hours (~6 hours/day for 7 days)

**Realistic**: Plan for 50 hours (buffer for issues)

---

## Common Issues and Solutions

### Issue 1: Holochain version mismatch
**Solution**: Pin versions in Cargo.toml, use exact versions from SYMBOLIC_FIRST_CORE.md

### Issue 2: Ontology too complex initially
**Solution**: Start with minimal types (Entity, Agent), add more later

### Issue 3: Triple extraction not working
**Solution**: Week 1 uses manual triples only; automate in Week 3

### Issue 4: Performance concerns
**Solution**: Cache validation results; optimize in Week 2

### Issue 5: Integration breaks existing tests
**Solution**: Run ADR-0 tests frequently; maintain backward compatibility

---

## Week 2 Preview

**After Week 1 complete, Week 2 will focus on**:
1. Domain-specific ontologies (AI/ML, research)
2. Inference axioms (transitive, symmetric relations)
3. Automatic reasoning tests
4. Performance optimization

---

## Resources

**Code references**:
- SYMBOLIC_FIRST_CORE.md → Integrity zome code
- ONTOLOGIES_AND_INTEGRATION.md → Ontology definitions
- conversation_memory.py → Integration point

**Documentation**:
- ADR-1 → Strategic commitment
- This checklist → Tactical execution
- Holochain docs → https://docs.holochain.org

---

**Status**: Ready to begin  
**Start date**: 2025-11-02  
**Target completion**: 2025-11-09  
**Daily standup**: Review progress against this checklist

---

**Ready to start Day 1?** 🚀
