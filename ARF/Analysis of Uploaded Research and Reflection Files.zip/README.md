# Rose Forest — Seed (v0.1)

**Goal:** Minimal, verifiable knowledge commons you can run locally: add a node, search by embedding, link edges — under budgeted writes and license/model-card rules.

## Prereqs
- Linux/macOS/WSL2
- Rust (stable), `wasm32-unknown-unknown` target
- `hc` (Holochain CLI) + Node 18+

## Install & Run
```bash
bash scripts/bootstrap.sh
bash scripts/launch.sh
```

This spawns a sandbox conductor with 2 agents and installs the DNA.

## Test

```bash
npm test
```

## Next Steps

- Swap the naive vector search for a local ANN snapshot
- Add `ModelCard` entries + `attest_model()` (proof-carrying models)
- Enforce joint RU×ε budget (privacy + risk)
- Add `explain()` to return an EvidenceGraph

**Ethos:** If it can’t be proved, it can’t be promoted. If it breaks the rules, it stops itself. Forks are features, not failures.




## Philosophy: Cognitive Liberation

The Rose Forest is more than a decentralized knowledge commons; it is an instrument for **cognitive liberation**. We aim to counteract the pervasive cognitive debt and unconscious extraction that define our current digital landscape.

Our architecture is designed to expose the mechanisms of cognitive capture and to provide tools for individuals and collectives to reclaim their cognitive sovereignty. This is achieved through a triadic process of **releasing parasitic operators, amplifying flourishing, and neutralizing exploiters**.

For a deeper dive into our foundational principles and the complete architectural synthesis, refer to [ARCHITECTURE.md](ARCHITECTURE.md).


