# Amazon Rose Forest — Seed Repo (v0.1)

**Virtual • Verifiable • Self‑Governing — local-first starter you can run on a single PC (Linux/macOS/WSL2).**

This is a minimal, working seed that:

- Packs a **Holochain DNA** with **Integrity** and **Coordinator** zomes
- Enforces **license + embedding bounds** and a **risk budget** on writes
- Provides a **naive vector search** and **edge linking**
- Ships **Tryorama** tests to smoke the flow end‑to‑end
- Uses simple scripts to **bootstrap** your machine and **run** locally

> ⚠️ **Versions**: Holochain moves fast. This seed pins reasonable defaults but you may need to bump `hdk/hdi` minor versions if crates drift. The code is simple and easy to adjust.

---

## 0) Repo layout

```
rose-forest-seed/
├─ .github/
│  └─ workflows/
│     └─ ci.yml
├─ .devcontainer/
│  └─ devcontainer.json
├─ README.md
├─ Makefile
├─ rust-toolchain.toml
├─ Cargo.toml                # Rust workspace (zomes)
├─ scripts/
│  ├─ bootstrap.sh           # Install toolchain + deps (Ubuntu/macOS/WSL2)
│  └─ launch.sh              # Pack DNA + spawn sandbox conductor
├─ dnas/
│  └─ rose_forest/
│     ├─ dna.yaml            # DNA packing manifest
│     ├─ zomes/
│     │  ├─ integrity/
│     │  │  ├─ Cargo.toml
│     │  │  └─ src/lib.rs
│     │  └─ coordinator/
│     │     ├─ Cargo.toml
│     │     └─ src/{lib.rs,vector_ops.rs,budget.rs}
│     └─ target/             # built wasm (ignored until build)
├─ tests/
│  └─ tryorama/rose_forest.test.ts
├─ package.json
└─ tsconfig.json
```

---

## 1) Quickstart

```bash
# 1) Clone and enter
git clone https://example.com/rose-forest-seed.git
cd rose-forest-seed

# 2) Bootstrap toolchain (Ubuntu/macOS/WSL2). Rerun if interrupted.
bash scripts/bootstrap.sh

# 3) Build wasm + pack DNA + run a local conductor with 2 agents
bash scripts/launch.sh

# 4) (Optional) Run the Tryorama smoke test
npm test
```

If `hc` complains about versions, open `dnas/rose_forest/zomes/*/Cargo.toml` and bump `hdk`/`hdi` minor versions in lockstep. Then rebuild.

---

## 2) Make targets

```Makefile
# Makefile
.PHONY: all build pack run test clean

all: build pack

build:
	cargo build --release --target wasm32-unknown-unknown -p rose_forest_integrity -p rose_forest_coordinator

pack:
	hc dna pack dnas/rose_forest -o dnas/rose_forest/rose_forest.dna

run:
	bash scripts/launch.sh

test:
	npm test

clean:
	rm -rf dnas/rose_forest/target dnas/rose_forest/rose_forest.dna target
```

---

## 3) Toolchain pinning

```toml
# rust-toolchain.toml
[toolchain]
channel = "stable"
targets = ["wasm32-unknown-unknown"]
profile = "minimal"
```

```toml
# Cargo.toml (workspace)
[workspace]
resolver = "2"
members = [
  "dnas/rose_forest/zomes/integrity",
  "dnas/rose_forest/zomes/coordinator"
]

[workspace.package]
edition = "2021"
```

---

## 4) DNA manifest

```yaml
# dnas/rose_forest/dna.yaml
manifest_version: "1"
name: "rose_forest"
integrity:
  network_seed: null
  properties: {}
  zomes:
    - name: rose_forest_integrity
      hash: null
      bundled: ./target/wasm32-unknown-unknown/release/rose_forest_integrity.wasm
coordinator:
  zomes:
    - name: rose_forest_coordinator
      hash: null
      bundled: ./target/wasm32-unknown-unknown/release/rose_forest_coordinator.wasm
```

---

## 5) Integrity zome (law)

```toml
# dnas/rose_forest/zomes/integrity/Cargo.toml
[package]
name = "rose_forest_integrity"
version = "0.1.0"
edition = "2021"

[lib]
crate-type = ["cdylib", "rlib"]

[dependencies]
hdi = "0.4"
serde = { version = "1", features = ["derive"] }
```

```rust
// dnas/rose_forest/zomes/integrity/src/lib.rs
use hdi::prelude::*;
use std::collections::BTreeMap;

#[hdk_entry_helper]
#[derive(Clone, PartialEq)]
pub struct RoseNode {
    pub content: String,
    pub embedding: Vec<f32>,
    pub license: String,
    pub metadata: BTreeMap<String, String>,
}

#[hdk_entry_helper]
#[derive(Clone, PartialEq)]
pub struct KnowledgeEdge {
    pub from: ActionHash,
    pub to: ActionHash,
    pub relationship: String,
    pub confidence: f32,
}

#[hdk_entry_helper]
#[derive(Clone, PartialEq)]
pub struct BudgetEntry {
    pub agent: AgentPubKey,
    pub remaining_ru: f32,
    pub window_start: Timestamp,
}

#[hdk_link_types]
pub enum LinkTypes { AllNodes, ShardMember, Edge, AgentBudget }

#[hdk_entry_defs]
#[unit_enum(UnitEntryTypes)]
pub enum EntryTypes {
    RoseNode(RoseNode),
    KnowledgeEdge(KnowledgeEdge),
    BudgetEntry(BudgetEntry),
}

#[hdk_extern]
pub fn validate(op: Op) -> ExternResult<ValidateCallbackResult> {
    match op.flattened::<EntryTypes, LinkTypes>()? {
        FlatOp::StoreEntry(store) => match store {
            OpEntry::CreateEntry { app_entry, .. } | OpEntry::UpdateEntry { app_entry, .. } => {
                match app_entry {
                    EntryTypes::RoseNode(node) => validate_rose_node(&node),
                    EntryTypes::KnowledgeEdge(edge) => validate_knowledge_edge(&edge),
                    EntryTypes::BudgetEntry(_) => Ok(ValidateCallbackResult::Valid),
                }
            }
            _ => Ok(ValidateCallbackResult::Valid),
        },
        _ => Ok(ValidateCallbackResult::Valid),
    }
}

fn validate_rose_node(node: &RoseNode) -> ExternResult<ValidateCallbackResult> {
    const VALID_LICENSES: &[&str] = &["MIT","Apache-2.0","BSD-3-Clause","MPL-2.0","CC-BY-4.0"];
    if !VALID_LICENSES.contains(&node.license.as_str()) {
        return Ok(ValidateCallbackResult::Invalid(format!("E_LICENSE: '{}' not allowed", node.license)));
    }
    let dim = node.embedding.len();
    if dim < 32 || dim > 4096 {
        return Ok(ValidateCallbackResult::Invalid(format!("E_EMBED_DIM: {} out of [32,4096]", dim)));
    }
    match (node.metadata.get("model_id"), node.metadata.get("model_card_hash")) {
        (Some(_), Some(hash)) if hash.starts_with("sha256:") => Ok(ValidateCallbackResult::Valid),
        _ => Ok(ValidateCallbackResult::Invalid("E_MODEL_CARD_MISSING".into())),
    }
}

fn validate_knowledge_edge(edge: &KnowledgeEdge) -> ExternResult<ValidateCallbackResult> {
    if !(0.0..=1.0).contains(&edge.confidence) {
        return Ok(ValidateCallbackResult::Invalid(format!("E_CONFIDENCE: {} out of [0,1]", edge.confidence)));
    }
    Ok(ValidateCallbackResult::Valid)
}
```

---

## 6) Coordinator zome (logic)

```toml
# dnas/rose_forest/zomes/coordinator/Cargo.toml
[package]
name = "rose_forest_coordinator"
version = "0.1.0"
edition = "2021"

[lib]
crate-type = ["cdylib", "rlib"]

[dependencies]
hdk = "0.4"
serde = { version = "1", features = ["derive"] }
serde_json = "1"
rose_forest_integrity = { path = "../integrity" }
```

```rust
// dnas/rose_forest/zomes/coordinator/src/vector_ops.rs
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Vector { pub values: Vec<f32> }
impl Vector {
    pub fn new(values: Vec<f32>) -> Self { Self { values } }
    pub fn cosine_similarity(&self, other: &Vector) -> f32 {
        let dot: f32 = self.values.iter().zip(other.values.iter()).map(|(a,b)| a*b).sum();
        let ma = self.values.iter().map(|x| x*x).sum::<f32>().sqrt();
        let mb = other.values.iter().map(|x| x*x).sum::<f32>().sqrt();
        if ma == 0.0 || mb == 0.0 { 0.0 } else { dot / (ma*mb) }
    }
}
```

```rust
// dnas/rose_forest/zomes/coordinator/src/budget.rs
use hdk::prelude::*;
use rose_forest_integrity::{BudgetEntry, LinkTypes};

pub const WINDOW_HOURS: i64 = 24;
pub const MAX_RU_PER_WINDOW: f32 = 100.0;
pub const COST_ADD_KNOWLEDGE: f32 = 1.0;
pub const COST_LINK_EDGE: f32 = 0.5;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BudgetState { pub remaining_ru: f32, pub window_start: Timestamp }

pub fn get_budget_state(agent: &AgentPubKey) -> ExternResult<BudgetState> {
    let path = Path::from(format!("budget.{}", agent));
    let links = get_links(GetLinksInputBuilder::try_new(path.path_entry_hash()?, LinkTypes::AgentBudget)?.build())?;
    if let Some(link) = links.first() {
        let record = get(link.target.clone(), GetOptions::default())?.ok_or(wasm_error!(WasmErrorInner::Guest("Budget not found".into())))?;
        let budget: BudgetEntry = record.entry().to_app_option()?.ok_or(wasm_error!(WasmErrorInner::Guest("Invalid budget".into())))?;
        let now = sys_time()?;
        let elapsed = now.as_secs_and_nanos().0.saturating_sub(budget.window_start.as_secs_and_nanos().0);
        if elapsed > (WINDOW_HOURS as u64 * 3600) { Ok(BudgetState{ remaining_ru: MAX_RU_PER_WINDOW, window_start: now }) }
        else { Ok(BudgetState{ remaining_ru: budget.remaining_ru, window_start: budget.window_start }) }
    } else { Ok(BudgetState{ remaining_ru: MAX_RU_PER_WINDOW, window_start: sys_time()? }) }
}

pub fn consume_budget(agent: &AgentPubKey, ru: f32) -> ExternResult<()> {
    let mut state = get_budget_state(agent)?;
    if state.remaining_ru < ru { return Err(wasm_error!(WasmErrorInner::Guest(format!("Budget exhausted: need {}, have {}", ru, state.remaining_ru)))) }
    state.remaining_ru -= ru;
    let budget = BudgetEntry { agent: agent.clone(), remaining_ru: state.remaining_ru, window_start: state.window_start };
    let budget_hash = create_entry(&budget)?;
    let path = Path::from(format!("budget.{}", agent));
    create_link(path.path_entry_hash()?, budget_hash, LinkTypes::AgentBudget, ())?;
    Ok(())
}
```

```rust
// dnas/rose_forest/zomes/coordinator/src/lib.rs
use hdk::prelude::*;
use rose_forest_integrity::*;

mod vector_ops; use vector_ops::Vector;
mod budget; use budget::{consume_budget, get_budget_state, BudgetState, COST_ADD_KNOWLEDGE, COST_LINK_EDGE};
use std::collections::BTreeMap;

#[derive(Serialize, Deserialize, Debug)]
pub struct AddNodeInput { pub content: String, pub embedding: Vec<f32>, pub license: String, pub metadata: BTreeMap<String,String> }
#[derive(Serialize, Deserialize, Debug)]
pub struct SearchInput { pub query_embedding: Vec<f32>, pub k: usize }
#[derive(Serialize, Deserialize, Debug)]
pub struct SearchResult { pub hash: ActionHash, pub score: f32, pub content: String }
#[derive(Serialize, Deserialize, Debug)]
pub struct AddEdgeInput { pub from: ActionHash, pub to: ActionHash, pub relationship: String, pub confidence: f32 }

#[hdk_extern]
pub fn add_knowledge(input: AddNodeInput) -> ExternResult<ActionHash> {
    let agent = agent_info()?.agent_latest_pubkey;
    consume_budget(&agent, COST_ADD_KNOWLEDGE)?;
    let node = RoseNode { content: input.content.clone(), embedding: input.embedding, license: input.license, metadata: input.metadata };
    let hash = create_entry(&node)?;
    let all_nodes_path = Path::from("all_nodes");
    create_link(all_nodes_path.path_entry_hash()?, hash.clone(), LinkTypes::AllNodes, ())?;
    let shard_key = format!("{:x}", hash.get_raw_36()[0]);
    let shard_path = Path::from(format!("shard.{}", shard_key));
    create_link(shard_path.path_entry_hash()?, hash.clone(), LinkTypes::ShardMember, ())?;
    Ok(hash)
}

#[hdk_extern]
pub fn vector_search(input: SearchInput) -> ExternResult<Vec<SearchResult>> {
    let query = Vector::new(input.query_embedding);
    let all_nodes_path = Path::from("all_nodes");
    let links = get_links(GetLinksInputBuilder::try_new(all_nodes_path.path_entry_hash()?, LinkTypes::AllNodes)?.build())?;
    let mut results: Vec<SearchResult> = Vec::new();
    for link in links {
        if let Some(record) = get(link.target.clone(), GetOptions::default())? {
            if let Some(node) = record.entry().to_app_option::<RoseNode>()? {
                let node_vec = Vector::new(node.embedding);
                let score = query.cosine_similarity(&node_vec);
                results.push(SearchResult { hash: link.target.into_action_hash().ok_or(wasm_error!(WasmErrorInner::Guest("Invalid hash".into())))?, score, content: node.content });
            }
        }
    }
    results.sort_by(|a,b| b.score.partial_cmp(&a.score).unwrap());
    results.truncate(input.k);
    Ok(results)
}

#[hdk_extern]
pub fn link_edge(input: AddEdgeInput) -> ExternResult<ActionHash> {
    let agent = agent_info()?.agent_latest_pubkey;
    consume_budget(&agent, COST_LINK_EDGE)?;
    let edge = KnowledgeEdge { from: input.from.clone(), to: input.to.clone(), relationship: input.relationship, confidence: input.confidence };
    let hash = create_entry(&edge)?;
    create_link(input.from, hash.clone(), LinkTypes::Edge, ())?;
    Ok(hash)
}

#[hdk_extern]
pub fn budget_status(_: ()) -> ExternResult<BudgetState> { get_budget_state(&agent_info()?.agent_latest_pubkey) }
```

---

## 7) Scripts

```bash
# scripts/bootstrap.sh
set -euo pipefail
OS=$(uname -s)
if ! command -v rustup >/dev/null; then curl https://sh.rustup.rs -sSf | sh -s -- -y; fi
source "$HOME/.cargo/env"
rustup target add wasm32-unknown-unknown

if ! command -v hc >/dev/null; then
  cargo install holochain_cli --locked || true
fi

if ! command -v npm >/dev/null; then
  echo "Install Node.js 18+ (e.g., via nvm) and rerun"; exit 1
fi
npm i
```

```bash
# scripts/launch.sh
set -euo pipefail
make build pack
# Spawn 2-agent sandbox and install the DNA to both
hc s clean
APP=rose_forest
DNA=dnas/rose_forest/rose_forest.dna
hc s generate "$DNA" --app-id $APP --num-agents 2 --run
```

---

## 8) Tryorama smoke test

```json
// package.json
{
  "name": "rose-forest-tests",
  "private": true,
  "scripts": { "test": "TS_NODE_TRANSPILE_ONLY=1 ts-node tests/tryorama/rose_forest.test.ts" },
  "devDependencies": {
    "@holochain/tryorama": "^0.14.0",
    "ts-node": "^10.9.2",
    "typescript": "^5.6.3"
  }
}
```

```json
// tsconfig.json
{ "compilerOptions": { "target": "es2020", "module": "commonjs", "strict": true } }
```

```ts
// tests/tryorama/rose_forest.test.ts
import { runScenario, dhtSync } from "@holochain/tryorama";
import path from "path";

test("add/search/link flow", async () => {
  await runScenario(async scenario => {
    const dna = path.resolve("dnas/rose_forest/rose_forest.dna");
    const app1 = await scenario.addPlayerWithApp({ bundle: { path: dna } });
    const app2 = await scenario.addPlayerWithApp({ bundle: { path: dna } });
    await dhtSync([app1, app2], 2000);

    const content = "Collective intelligence 101";
    const embedding = Array(128).fill(0).map((_,i)=> i===0?1:0);
    const metadata = { model_id:"text-embed-001", model_card_hash:"sha256:deadbeef" };

    const hash: any = await app1.cells[0].callZome({ zome_name:"rose_forest_coordinator", fn_name:"add_knowledge", payload: { content, embedding, license:"MIT", metadata } });
    await dhtSync([app1, app2], 2000);

    const results: any[] = await app2.cells[0].callZome({ zome_name:"rose_forest_coordinator", fn_name:"vector_search", payload: { query_embedding: embedding, k: 3 } });
    expect(results.length).toBeGreaterThan(0);

    const linkHash: any = await app2.cells[0].callZome({ zome_name:"rose_forest_coordinator", fn_name:"link_edge", payload: { from: hash, to: results[0].hash, relationship: "cites", confidence: 0.9 } });
    expect(linkHash).toBeTruthy();
  });
}, 60000);
```

---

## 9) README (top-level)

````md
# Rose Forest — Seed (v0.1)

**Goal:** Minimal, verifiable knowledge commons you can run locally: add a node, search by embedding, link edges — under budgeted writes and license/model-card rules.

## Prereqs
- Linux/macOS/WSL2
- Rust (stable), `wasm32-unknown-unknown` target
- `hc` (Holochain CLI) + Node 18+

## Install & Run
```bash
bash scripts/bootstrap.sh
bash scripts/launch.sh
````

This spawns a sandbox conductor with 2 agents and installs the DNA.

## Test

```bash
npm test
```

## Next Steps

- Swap the naive vector search for a local ANN snapshot
- Add `ModelCard` entries + `attest_model()` (proof-carrying models)
- Enforce joint RU×ε budget (privacy + risk)
- Add `explain()` to return an EvidenceGraph

**Ethos:** If it can’t be proved, it can’t be promoted. If it breaks the rules, it stops itself. Forks are features, not failures.

````

---

## 10) Notes
- **Windows**: Use WSL2 (Ubuntu 22.04+). Run everything inside the Linux shell.
- **Holochain versions**: If `cargo build` errors on `hdk/hdi` versions, bump both to the latest compatible `0.4.x` and rebuild.
- **Security**: This is a local seed. Before WAN exposure, add RuleEngine hardening and proof-carrying envelopes.

---

## 11) FLOSSI0ULLK hooks (where values meet code)
- **Love (agency)**: Per‑agent budgets prevent domination; anyone can fork DNA and self‑host.
- **Light (transparency)**: Validation rules are visible in integrity zome; tests document behavior.
- **Knowledge (commons)**: Every node is licensed OSI/CC‑BY; embeddings must cite model cards.

---

**You now have a skeleton that compiles to Wasm, packs into a DNA, runs in a sandbox, and proves the autonomy loop.**



---

## 12) GitHub Actions CI

Create `.github/workflows/ci.yml`:

```yaml
name: CI

on:
  push:
    branches: ["**"]
  pull_request:

jobs:
  build-test:
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@v4

      - name: Setup Rust
        uses: dtolnay/rust-toolchain@stable
        with:
          targets: wasm32-unknown-unknown

      - name: Cache cargo
        uses: actions/cache@v4
        with:
          path: |
            ~/.cargo/registry
            ~/.cargo/git
            target
          key: ${{ runner.os }}-cargo-${{ hashFiles('**/Cargo.lock') }}
          restore-keys: ${{ runner.os }}-cargo-

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: "20"
          cache: npm

      - name: Install Node deps
        run: npm ci

      - name: Build zomes (Wasm)
        run: cargo build --release --target wasm32-unknown-unknown -p rose_forest_integrity -p rose_forest_coordinator

      - name: Install Holochain CLI
        run: cargo install holochain_cli --locked

      - name: Pack DNA
        run: hc dna pack dnas/rose_forest -o dnas/rose_forest/rose_forest.dna

      - name: Run Tryorama tests
        env:
          TS_NODE_TRANSPILE_ONLY: "1"
        run: npm test
````

**What this does:** builds Wasm zomes, packs the DNA, and runs the Tryorama smoke test on every push/PR.

---

## 13) Devcontainer (VS Code / Codespaces)

Create `.devcontainer/devcontainer.json`:

```json
{
  "name": "Rose Forest Dev",
  "image": "mcr.microsoft.com/devcontainers/base:ubuntu",
  "features": {
    "ghcr.io/devcontainers/features/rust:1": { "version": "stable", "profile": "minimal" },
    "ghcr.io/devcontainers/features/node:1": { "version": "20" }
  },
  "postCreateCommand": "bash -lc 'rustup target add wasm32-unknown-unknown && cargo install holochain_cli --locked && npm i'",
  "customizations": {
    "vscode": {
      "extensions": [
        "rust-lang.rust-analyzer",
        "tamasfe.even-better-toml",
        "serayuzgur.crates",
        "esbenp.prettier-vscode",
        "dbaeumer.vscode-eslint"
      ],
      "settings": {
        "rust-analyzer.cargo.target": "wasm32-unknown-unknown",
        "editor.formatOnSave": true
      }
    }
  }
}
```

**Use it:**

- Open the folder in VS Code → **Dev Containers: Reopen in Container** (or use GitHub Codespaces).
- Terminal inside the container:
  ```bash
  make build pack && npm test
  ```

---

## 14) README additions (CI badge & Devcontainer)

Add to the top of `README.md` (replace `YOUR_REPO` once you push):

```md
[![CI](https://github.com/YOUR_ORG/YOUR_REPO/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_ORG/YOUR_REPO/actions/workflows/ci.yml)
```

Add a section:

```md
## Devcontainer
If you use VS Code or Codespaces, open this repo and select **Reopen in Container**. The container preinstalls Rust, Node 20, Holochain CLI, and the wasm toolchain.
```

---

## 15) Notes on CI stability

- If `hdk/hdi` drift, the CI will fail fast on `cargo build`. Bump both to matching `0.4.x`.
- `hc` downloads conductor binaries as needed; no WAN ports are opened in CI.
- Keep tests under 90s to avoid flaky timeouts; the sample Tryorama test is capped at 60s.

