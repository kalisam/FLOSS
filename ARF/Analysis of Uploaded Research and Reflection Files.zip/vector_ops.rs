pub struct Vector(pub Vec<f32>);

impl Vector {
    pub fn new(data: Vec<f32>) -> Self {
        Vector(data)
    }

    pub fn cosine_similarity(&self, other: &Self) -> f32 {
        if self.0.is_empty() || other.0.is_empty() || self.0.len() != other.0.len() {
            return 0.0; // Or return an error, depending on desired behavior
        }

        let dot_product: f32 = self.0.iter().zip(other.0.iter()).map(|(&a, &b)| a * b).sum();
        let magnitude_self: f32 = self.0.iter().map(|&a| a * a).sum::<f32>().sqrt();
        let magnitude_other: f32 = other.0.iter().map(|&b| b * b).sum::<f32>().sqrt();

        if magnitude_self == 0.0 || magnitude_other == 0.0 {
            return 0.0;
        }

        dot_product / (magnitude_self * magnitude_other)
    }
}


